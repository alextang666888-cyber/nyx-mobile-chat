// Populated from Nyx static assets by the cloud build.
export const ASSETS = {};
