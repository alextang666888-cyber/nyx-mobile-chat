// Reproduce the hosted Worker from the downloadable corresponding source.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const names=['index.html','app.css','app.js','config.js','paper.js','home.js','water.js','tree.js','hold.js','startup.js','startup.css','settings.js','settings.css','hosted-bridge.js','demo.js','sw.js','manifest.webmanifest','icon-180.png','icon-192.png','icon-512.png','star.svg','credits.html','LICENSE','source.zip'];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const full=path.join(dir,e.name);if(e.isDirectory())walk(full);else names.push(path.relative(root,full).replaceAll('\\','/'));}}walk(path.join(root,'fonts'));
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webmanifest':'application/manifest+json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.zip':'application/zip'},assets={};
for(const name of names){let data=fs.readFileSync(path.join(root,name));if(name==='config.js')data=Buffer.concat([Buffer.from('window.NYX_HOSTED=true;window.NYX_PREVIEW_ONLY=false;\n'),data]);assets[name]=[types[path.extname(name)]||'text/plain; charset=utf-8',data.toString('base64')];}
const provider=fs.readFileSync(path.join(root,'cloud/provider.mjs'),'utf8').replaceAll('export ','');
const worker=fs.readFileSync(path.join(root,'cloud/worker.mjs'),'utf8').replace(/^import .*;\r?\n/gm,'');
const out=path.join(root,'.cloud-build');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'index.mjs'),'const ASSETS='+JSON.stringify(assets)+';\n'+provider+'\n'+worker);console.log(path.join(out,'index.mjs'));
