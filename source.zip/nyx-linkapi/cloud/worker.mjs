import {ApiError,publicConfig,candidate,discover,seal,unseal,chat} from './provider.mjs';
import {ASSETS} from './assets.mjs';
const COOKIE='__Host-nyx-provider';
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});}
export default {async fetch(request,env){
  const url=new URL(request.url),path=url.pathname;
  if(path.startsWith('/api/')){
    try{
      const user=request.headers.get('oai-authenticated-user-id');
      if(!user)throw new ApiError(401,'请使用当前网站的 ChatGPT 登录入口重新登录。');
      if(request.method==='POST'&&request.headers.get('origin')&&request.headers.get('origin')!==url.origin)throw new ApiError(403,'请从当前网站打开设置。');
      const token=(request.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);
      const old=await unseal(token,env.NYX_SETTINGS_KEY,user);
      if(path==='/api/provider'&&request.method==='GET')return json(publicConfig(old));
      if(request.method!=='POST')throw new ApiError(405,'不支持这个操作。');
      if(Number(request.headers.get('content-length')||0)>100000)throw new ApiError(413,'提交内容过大。');
      const raw=await request.text();if(raw.length>100000)throw new ApiError(413,'提交内容过大。');
      let body;try{body=JSON.parse(raw);}catch(e){throw new ApiError(400,'提交格式不正确。');}
      if(path==='/api/chat')return await chat(old,body.messages);
      if(path==='/api/provider/discover')return json(await discover(candidate(body,old)));
      if(path==='/api/provider'){
        const cfg=candidate(body,old),catalog=await discover(cfg);
        const selected=catalog.models.find(m=>m.id===body.model);
        if(!selected)throw new ApiError(400,'请选择这把 API key 返回的可用模型。');
        Object.assign(cfg,{model:selected.id,protocol:selected.protocol,group:String(body.group||'').slice(0,100)});
        const value=await seal(cfg,env.NYX_SETTINGS_KEY,user);
        return json(publicConfig(cfg),200,{'Set-Cookie':COOKIE+'='+value+'; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000'});
      }
      throw new ApiError(404,'没有这个接口。');
    }catch(e){return json({detail:e instanceof ApiError?e.message:'请求未完成，请检查网络后重试。'},e instanceof ApiError?e.status:502);}
  }
  const name=path==='/'?'index.html':path.slice(1),asset=ASSETS[name];
  if(!asset)return new Response('Not found',{status:404});
  const bytes=Uint8Array.from(atob(asset[1]),c=>c.charCodeAt(0));
  return new Response(bytes,{headers:{'Content-Type':asset[0],'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});
}};
