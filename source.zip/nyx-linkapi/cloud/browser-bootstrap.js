// Browser-only BYOK adapter. No website accounts or chat relay are used.
if(!window.NYX_BROWSER_ONLY)return;
const networkFetch=window.fetch.bind(window);
const SESSION='nyx_direct_api_session_v1',PERSISTED='nyx_direct_api_saved_v1';
function readConfig(){
  try{return JSON.parse(sessionStorage.getItem(SESSION)||localStorage.getItem(PERSISTED)||'null');}
  catch(e){return null;}
}
function visible(cfg){return {base_url:cfg?.base_url||'https://linkapi.ai',model:cfg?.model||'',group:cfg?.group||'',protocol:cfg?.protocol||'',key_set:!!cfg?.api_key,remember:!!cfg?.remember,storage:cfg?.remember?'browser_local':'browser_session'};}
function result(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});}
async function directFetch(url,options={}){
  const target=new URL(url),headers=new Headers(options.headers||{});
  // LinkAPI accepts x-api-key on /v1/models; it avoids Authorization's stricter CORS rule.
  if(/(^|\.)linkapi\.(ai|pro|cc)$/.test(target.hostname)&&target.pathname==='/v1/models'&&headers.has('Authorization')){
    headers.set('x-api-key',headers.get('Authorization').replace(/^Bearer\s+/i,''));headers.delete('Authorization');
  }
  return networkFetch(url,{...options,headers,mode:'cors',credentials:'omit'});
}
window.fetch=async function(input,options={}){
  const url=new URL(typeof input==='string'?input:input.url,location.href);
  if(url.origin!==location.origin||!['/api/provider','/api/provider/discover','/api/chat'].includes(url.pathname))return networkFetch(input,options);
  try{
    const old=readConfig(),method=options.method||'GET';
    if(url.pathname==='/api/provider'&&method==='GET')return result(visible(old));
    if(method!=='POST')throw new ApiError(405,'不支持这个操作。');
    const body=JSON.parse(options.body||'{}');
    if(url.pathname==='/api/chat')return await chat(old,body.messages,directFetch,window.NyxMemory,{interaction_mode:body.interaction_mode,signal:options.signal});
    const cfg=candidate(body,old),catalog=await discover(cfg,directFetch);
    if(url.pathname==='/api/provider/discover')return result(catalog);
    const selected=catalog.models.find(m=>m.id===body.model);
    if(!selected)throw new ApiError(400,'请从读取到的可用列表中选择模型。');
    Object.assign(cfg,{model:selected.id,protocol:selected.protocol,group:String(body.group||'').slice(0,100),remember:body.remember===true});
    try{
      if(cfg.remember){localStorage.setItem(PERSISTED,JSON.stringify(cfg));sessionStorage.removeItem(SESSION);}
      else{sessionStorage.setItem(SESSION,JSON.stringify(cfg));localStorage.removeItem(PERSISTED);}
    }catch(e){throw new ApiError(400,'浏览器阻止了保存，请关闭隐私限制或换一个浏览器。');}
    return result(visible(cfg));
  }catch(e){options.signal?.throwIfAborted();return result({detail:e instanceof ApiError?e.message:'连接未完成。这家服务商可能不允许浏览器直接访问，请检查接口地址和网络。'},e instanceof ApiError?e.status:502);}
};
