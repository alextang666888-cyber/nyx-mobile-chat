import assert from 'node:assert/strict';
import {ApiError,normalizeBase,candidate,discover,seal,unseal,publicConfig,chat} from '../cloud/provider.mjs';
import worker from '../cloud/worker.mjs';
const cfg={base_url:'https://linkapi.ai',api_key:'fake-key-for-tests',model:'claude-opus-4-6-r',protocol:'anthropic'};
const paths=[];
const mock=async(url,options={})=>{
 paths.push(url);
 if(url.endsWith('/v1/models')){assert.equal(options.headers.Authorization,'Bearer fake-key-for-tests');return Response.json({data:[{id:cfg.model},{id:'image-only'}]});}
 if(url.endsWith('/api/pricing'))return Response.json({success:true,usable_group:{default:'Default route'},data:[{model_name:cfg.model,enable_groups:['default'],supported_endpoint_types:['anthropic','openai']},{model_name:'image-only',supported_endpoint_types:['image-generation']}]});
 if(url.endsWith('/v1/messages')){assert.equal(options.headers['x-api-key'],cfg.api_key);assert.equal(JSON.parse(options.body).model,cfg.model);return new Response('data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"MOCK_REPLY"}}\n\ndata: {"type":"message_stop"}\n\n',{headers:{'Content-Type':'text/event-stream'}});}
 throw Error('unexpected URL');
};
assert.equal(normalizeBase('https://linkapi.ai/v1/'),'https://linkapi.ai/v1');
for(const url of ['http://linkapi.ai','https://127.0.0.1','https://host.local','https://u:p@linkapi.ai','https://linkapi.ai/v1/messages'])assert.throws(()=>normalizeBase(url));
assert.equal(candidate({base_url:cfg.base_url},cfg).api_key,cfg.api_key);
assert.throws(()=>candidate({base_url:'https://other.example'},cfg));
const catalog=await discover(cfg,mock);assert.equal(catalog.models.length,1);assert.equal(catalog.groups[0].id,'default');assert.equal(catalog.group_mode,'catalog_filter');
const token=await seal(cfg,'random-test-key-not-production','user-a');assert(!token.includes(cfg.api_key));
assert.equal((await unseal(token,'random-test-key-not-production','user-a')).api_key,cfg.api_key);
assert.equal(await unseal(token,'random-test-key-not-production','user-b'),null);
assert.equal(await unseal(token,'different-key','user-a'),null);
assert(!JSON.stringify(publicConfig(cfg)).includes(cfg.api_key));
const answer=await chat(cfg,[{role:'user',content:'Hello'}],mock);const wire=await answer.text();assert(wire.includes('MOCK_REPLY'));assert(wire.includes('"type":"done"'));assert(!wire.includes(cfg.api_key));
const broken=await chat(cfg,[{role:'user',content:'Hello'}],async()=>new Response('data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"partial"}}\n\n'));
assert((await broken.text()).includes('"type":"error"'));
assert.equal((await worker.fetch(new Request('https://site.example/api/provider'),{})).status,401);
const cross=new Request('https://site.example/api/provider',{method:'POST',headers:{'oai-authenticated-user-id':'user-a','origin':'https://evil.example'},body:'{}'});
assert.equal((await worker.fetch(cross,{})).status,403);
const realFetch=globalThis.fetch;globalThis.fetch=mock;
try{
 const req=new Request('https://site.example/api/provider',{method:'POST',headers:{'oai-authenticated-user-id':'user-a',origin:'https://site.example'},body:JSON.stringify(cfg)});
 const saved=await worker.fetch(req,{NYX_SETTINGS_KEY:'random-test-key-not-production'});assert.equal(saved.status,200);assert(!await saved.clone().text().then(t=>t.includes(cfg.api_key)));
 const cookie=saved.headers.get('Set-Cookie');assert(cookie.includes('HttpOnly'));assert(cookie.includes('Secure'));assert(cookie.includes('SameSite=Strict'));
 const read=await worker.fetch(new Request('https://site.example/api/provider',{headers:{'oai-authenticated-user-id':'user-a',cookie}}),{NYX_SETTINGS_KEY:'random-test-key-not-production'});assert.equal((await read.json()).model,cfg.model);
}finally{globalThis.fetch=realFetch;}
console.log('PASS: catalog, groups, selection, encrypted session, identity, save/read, streaming and interrupted stream');
