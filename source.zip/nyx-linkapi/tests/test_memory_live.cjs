const {chromium}=require('D:/CodexProjects/.cache/nyx-ui-qa/node_modules/playwright-core');
const fs=require('node:fs'),assert=require('node:assert/strict');
const root='https://alextang666888-cyber.github.io/nyx-mobile-chat/';
(async()=>{
 const context=await chromium.launchPersistentContext('D:/CodexProjects/user-temp/nyx-live-memory-qa-'+Date.now(),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,viewport:{width:360,height:740},isMobile:true,hasTouch:true,args:['--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-breakpad','--disable-crash-reporter','--disable-sync'],env:{...process.env,TEMP:'D:/CodexProjects/user-temp',TMP:'D:/CodexProjects/user-temp'}});
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto(root+'?v=20261111-memory1#chat',{waitUntil:'domcontentloaded'});await page.waitForSelector('#memoryOpen',{timeout:30000});assert.equal(await page.evaluate(()=>window.NYX_BROWSER_ONLY),true);
  await page.click('#memoryOpen');assert(await page.locator('#memoryConnect').isVisible());await page.screenshot({path:'D:/CodexProjects/outputs/nyx-memory-qa/live-memory-entry.png'});
  const registration=page.waitForResponse(r=>r.url().endsWith('/oauth/register'));
  await page.click('#memoryConnect');const response=await registration;assert.equal(response.status(),201);await page.waitForURL('https://ombre-brain-nzh4.onrender.com/oauth/authorize?**',{timeout:30000});
  const u=new URL(page.url());assert.equal(u.searchParams.get('redirect_uri'),root);assert.equal(u.searchParams.get('code_challenge_method'),'S256');assert.equal(u.searchParams.get('scope'),'mcp');
  const passwordCount=await page.locator('input[type=password]').count();const body=await page.locator('body').innerText();assert(passwordCount>0||/登录|授权|authorize|login/i.test(body),'Expected original private authorization page');await page.screenshot({path:'D:/CodexProjects/outputs/nyx-memory-qa/live-ob-authorization.png'});
  assert.equal(errors.length,0,JSON.stringify(errors));const result={passed:true,site:root,browserOnly:true,registrationStatus:response.status(),authorizationOrigin:u.origin,pkce:true,correctCallback:true,passwordInputPresent:passwordCount>0,privateLoginSubmitted:false,privateMemoriesRead:false,privateMemoriesWritten:false,errors};fs.writeFileSync('D:/CodexProjects/outputs/nyx-memory-qa/live-report.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{await context.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
