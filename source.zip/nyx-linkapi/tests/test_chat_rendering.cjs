const {chromium}=require('D:/CodexProjects/.cache/nyx-ui-qa/node_modules/playwright-core');
const fs=require('node:fs'),assert=require('node:assert/strict');
const out='D:/CodexProjects/outputs/nyx-chat-qa';fs.mkdirSync(out,{recursive:true});
(async()=>{
 const context=await chromium.launchPersistentContext('D:/CodexProjects/user-temp/nyx-chat-qa-'+Date.now(),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,viewport:{width:360,height:740},isMobile:true,hasTouch:true,args:['--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-breakpad','--disable-crash-reporter','--disable-sync'],env:{...process.env,TEMP:'D:/CodexProjects/user-temp',TMP:'D:/CodexProjects/user-temp'}});
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('https://cdn.jsdelivr.net/**',r=>r.fulfill({status:200,contentType:'text/css',body:''}));
 await page.route('https://ombre-brain-nzh4.onrender.com/**',r=>r.abort());
 await page.addInitScript(()=>{
  sessionStorage.setItem('nyx_direct_api_session_v1',JSON.stringify({base_url:'https://linkapi.ai',api_key:'mock-key',model:'claude-opus-4-6-r',protocol:'anthropic'}));
  if(!localStorage.getItem('nyx_cloud_chat_v1'))localStorage.setItem('nyx_cloud_chat_v1',JSON.stringify(Array.from({length:8},(_,i)=>({id:i+1,ts:new Date().toISOString(),from:i%2?'ai':'human',kind:i%2?'reply':'user',text:'布局测试历史消息 '+i+'。'.repeat(90),meta:{}}))));
  const original=window.fetch.bind(window);window.__modelRequests=0;
  window.fetch=(input,options)=>{
   if(String(input)==='https://linkapi.ai/v1/messages'){
    window.__modelRequests++;const request=JSON.parse(options.body),last=request.messages.at(-1).content,fail=last.includes('中断');
    const paragraph='这是同一条回复中的一段文字，用来检查连续生成时的气泡与滚动位置。'.repeat(3)+'\n\n';
    const events=[{type:'content_block_start',index:0,content_block:{type:'text',text:''}},...Array.from({length:18},(_,i)=>({type:'content_block_delta',index:0,delta:{type:'text_delta',text:(i+1)+' '+paragraph}})),...(fail?[]:[{type:'message_stop'}])];
    let i=0,timer;const stream=new ReadableStream({start(c){function emit(){if(i===events.length){c.close();return;}c.enqueue(new TextEncoder().encode('data: '+JSON.stringify(events[i++])+'\n\n'));timer=setTimeout(emit,55);}emit();},cancel(){clearTimeout(timer);}});return Promise.resolve(new Response(stream,{headers:{'Content-Type':'text/event-stream'}}));
   }return original(input,options);
  };
 });
 async function finish(turn){await page.waitForFunction(n=>JSON.parse(localStorage.getItem('nyx_cloud_chat_v1')).length===8+n*2,turn);await page.waitForTimeout(100);const result=await page.evaluate(()=>({count:document.querySelectorAll('#log .msg').length,drafts:document.querySelectorAll('#log .draft').length,order:[...document.querySelectorAll('#log .msg')].map(e=>({id:e.dataset.id,from:e.dataset.from})),gap:document.querySelector('#log').scrollHeight-document.querySelector('#log').scrollTop-document.querySelector('#log').clientHeight}));assert.equal(result.drafts,0,'finished reply left an extra streaming bubble');assert.equal(result.count,8+turn*2,'one bubble per persisted message');assert.deepEqual(result.order.map(x=>Number(x.id)),Array.from({length:8+turn*2},(_,i)=>i+1));assert.deepEqual(result.order.slice(-2).map(x=>x.from),['human','ai']);return result;}
 try{
  await page.goto((process.env.NYX_QA_URL||'http://127.0.0.1:8089/')+'#chat');await page.waitForSelector('#room:not([hidden])');await page.waitForTimeout(200);
  await page.fill('#text','测试同样的消息');await page.click('#send');await page.waitForSelector('#log .draft');const first=await finish(1);assert(first.gap<100,'long reply stopped following bottom');
  await page.screenshot({path:out+'/chat-fixed.png'});
  await page.fill('#text','测试同样的消息');await page.click('#send');await page.waitForSelector('#log .draft');await page.locator('#text').evaluate(e=>e.blur());await page.locator('#log').evaluate(e=>{e.scrollTop=0;});await finish(2);assert(await page.locator('#log').evaluate(e=>e.scrollTop<200),'reply forced reader away from older messages');
  const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('nyx_cloud_chat_v1')));assert.equal(saved[9].text,saved[11].text,'same legitimate reply can appear in different turns');assert.equal(await page.evaluate(()=>window.__modelRequests),2,'no repeated model request');
  await page.reload();await page.waitForSelector('#room:not([hidden])');await finish(2);
  await page.fill('#text','测试中断');await page.click('#send');await finish(3);assert((await page.evaluate(()=>JSON.parse(localStorage.getItem('nyx_cloud_chat_v1')).at(-1))).meta.api_error);assert.equal(await page.evaluate(()=>window.__modelRequests),1);
  assert.equal(errors.length,0,JSON.stringify(errors));fs.writeFileSync(out+'/report.json',JSON.stringify({passed:true,streamingDedup:true,order:true,followBottom:true,readingOlderPreserved:true,repeatedIdenticalMessagesPreserved:true,reload:true,interruptedStream:true,mockOnly:true,errors},null,2));console.log('PASS: one bubble per message, ordered repeated turns, long reply follow, reading older preserved, reload and interrupted reply');
 }catch(e){await page.screenshot({path:out+'/failure.png'});throw e;}finally{await context.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
