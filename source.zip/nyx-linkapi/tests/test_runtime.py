import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TEST_DATA = tempfile.TemporaryDirectory(prefix='runtime-', dir=ROOT / 'test-results')
os.environ['NYX_DATA_DIR'] = TEST_DATA.name
os.environ['RELAY_SECRET'] = 'test-access-key-that-is-not-a-real-secret'
os.environ.pop('OB_MCP_URL', None)
os.environ.pop('LLM_API_KEY', None)
import runtime as rt
from anthropic_adapter import complete, endpoint, request_body
import httpx


def sse(text='hello', tool=False, stop=True):
    events = [{'type': 'message_start', 'message': {'usage': {'input_tokens': 13}}}]
    if tool:
        events += [{'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'tool_use', 'id': 'call-1', 'name': 'ombre__pulse', 'input': {}}}, {'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'input_json_delta', 'partial_json': '{}'}}]
    else:
        events += [{'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}}, {'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'text_delta', 'text': text}}]
    events += [{'type': 'message_delta', 'usage': {'output_tokens': 4}}]
    if stop:
        events += [{'type': 'message_stop'}]
    return ''.join('data: ' + json.dumps(e) + '\n\n' for e in events)


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_native_stream_tools_and_usage(self):
        seen = []
        def handler(req):
            body = json.loads(req.content)
            self.assertEqual(req.url.path, '/v1/messages')
            self.assertEqual(req.headers['x-api-key'], 'fake-provider-key')
            self.assertNotIn('Authorization', req.headers)
            seen.append(body)
            return httpx.Response(200, text=sse(tool=True), headers={'content-type': 'text/event-stream'})
        chunks = []
        async def sink(t): chunks.append(t)
        result = await complete({'url': 'https://test.invalid/v1', 'key': 'fake-provider-key', 'model': 'claude-opus-4-6-r'}, [{'role': 'system', 'content': 'persona'}, {'role': 'user', 'content': 'hi'}], [{'function': {'name': 'ombre__pulse', 'parameters': {'type': 'object'}}}], max_tokens=2000, stream=True, sink=sink, error_type=rt.loop.ModelError, transport=httpx.MockTransport(handler))
        self.assertEqual(result['tool_calls'][0]['arguments'], '{}')
        self.assertEqual(result['usage']['input_tokens'], 13)
        self.assertEqual(seen[0]['system'][0]['text'], 'persona')
        self.assertEqual(seen[0]['tools'][0]['input_schema']['type'], 'object')
        self.assertEqual(chunks, [])

    async def test_truncated_stream_fails_without_retry(self):
        count = []
        def handler(req):
            count.append(1)
            return httpx.Response(200, text=sse('partial', stop=False))
        async def sink(t): pass
        with self.assertRaises(rt.loop.ModelError):
            await complete({'url': 'https://test.invalid', 'key': 'fake', 'model': 'm'}, [{'role': 'user', 'content': 'hi'}], None, max_tokens=20, stream=True, sink=sink, error_type=rt.loop.ModelError, transport=httpx.MockTransport(handler))
        self.assertEqual(len(count), 1)

    async def test_provider_error_does_not_echo_secret(self):
        async def sink(t): pass
        def handler(req): return httpx.Response(401, text='secret-reflected-value')
        with self.assertRaises(rt.loop.ModelError) as ctx:
            await complete({'url': 'https://test.invalid', 'key': 'fake', 'model': 'm'}, [], None, max_tokens=20, stream=False, sink=sink, error_type=rt.loop.ModelError, transport=httpx.MockTransport(handler))
        self.assertNotIn('secret-reflected-value', str(ctx.exception))

    async def test_tool_result_translation_and_base_url(self):
        messages = [{'role': 'assistant', 'content': None, 'tool_calls': [{'id': 'c1', 'function': {'name': 'pulse', 'arguments': '{}'}}]}, {'role': 'tool', 'tool_call_id': 'c1', 'content': 'memory'}, {'role': 'user', 'content': 'continue'}]
        body = request_body({'model': 'm'}, messages, None, 100, False)
        self.assertEqual(body['messages'][0]['content'][0]['type'], 'tool_use')
        self.assertEqual(body['messages'][1]['content'][0]['tool_use_id'], 'c1')
        self.assertEqual(len(body['messages'][1]['content']), 2)
        for base in ['https://host', 'https://host/v1', 'https://host/v1/messages']:
            self.assertEqual(endpoint(base), 'https://host/v1/messages')


class RuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.life = rt.lifespan(rt.app)
        await self.life.__aenter__()
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=rt.app), base_url='http://localhost')
        self.headers = {'Authorization': 'Bearer ' + rt.relay.SECRET}

    async def asyncTearDown(self):
        await self.client.aclose()
        await self.life.__aexit__(None, None, None)

    async def test_auth_secret_files_and_admin_routes(self):
        for path in ['/relay/app/history', '/relay/app/connection']:
            self.assertEqual((await self.client.get(path)).status_code, 401)
        for path in ['/.env', '/data/access-key.txt', '/runtime.py', '/relay/app/loop/config', '/relay/channel/out']:
            self.assertEqual((await self.client.get(path, headers=self.headers)).status_code, 404)
        r = await self.client.get('/relay/app/connection', headers=self.headers)
        self.assertFalse(r.json()['memory_online'])
        self.assertNotIn(rt.relay.SECRET, r.text)
        self.assertEqual(r.headers['Cache-Control'], 'no-store')

    async def test_no_key_refuses_message_and_does_not_persist_it(self):
        r = await self.client.post('/relay/app/send', headers=self.headers, json={'text': 'no-key-message'})
        self.assertEqual(r.status_code, 503)
        h = (await self.client.get('/relay/app/history', headers=self.headers)).json()
        self.assertNotIn('no-key-message', json.dumps(h))

    async def test_memory_tool_roundtrip_stream_persistence_and_history(self):
        calls, requests = [], []
        class FakeMemory:
            name = 'ombre'
            session = object()
            tools = [SimpleNamespace(name=n, inputSchema={'type': 'object', 'properties': {'query': {'type': 'string'}} if n=='breath_search' else {}}, description=n) for n in ['breath_search', 'pulse', 'hold', 'delete_memory']]
            async def call(self, tool, args):
                calls.append((tool, args))
                return SimpleNamespace(content=[SimpleNamespace(type='text', text='TEST_MEMORY_ONLY')], isError=False)
        mem = FakeMemory()
        index = {rt.loop.tool_public_name('ombre', t.name): ('ombre', t.name) for t in mem.tools}
        def handler(req):
            body = json.loads(req.content)
            requests.append(body)
            if len(requests) == 1:
                # Use dynamically generated upstream MCP public name.
                wire = sse(tool=True).replace('ombre__pulse', rt.loop.tool_public_name('ombre', 'pulse'))
                return httpx.Response(200, text=wire)
            return httpx.Response(200, text=sse('MOCK_CLAUDE_REPLY'))
        original_complete = rt.complete
        async def fake_complete(*args, **kw):
            return await original_complete(*args, **kw, transport=httpx.MockTransport(handler))
        with patch.dict(os.environ, {'LLM_API_KEY': 'fake-provider-key'}), patch.object(rt, 'ob_url', 'https://memory.invalid/mcp'), patch.dict(rt.loop.mcp_manager.servers, {'ombre': mem}), patch.dict(rt.loop.mcp_manager.index, index), patch.object(rt, 'complete', fake_complete):
            r = await self.client.post('/relay/app/send', headers=self.headers, json={'text': 'MOCK_USER_MESSAGE'})
            self.assertEqual(r.status_code, 200)
            for _ in range(200):
                if not rt.turn_lock.locked(): break
                await asyncio.sleep(0.01)
            self.assertFalse(rt.turn_lock.locked())
            history = (await self.client.get('/relay/app/history', headers=self.headers)).json()['messages']
            self.assertTrue(any(m['text']=='MOCK_CLAUDE_REPLY' for m in history), history)
            self.assertEqual(calls[0], ('breath_search', {'query': 'MOCK_USER_MESSAGE'}))
            self.assertEqual(calls[1][0], 'pulse')
            self.assertEqual(len(requests), 2)
            advertised = [t['name'] for t in requests[0]['tools']]
            self.assertNotIn(rt.loop.tool_public_name('ombre', 'hold'), advertised)
            self.assertNotIn(rt.loop.tool_public_name('ombre', 'delete_memory'), advertised)
            self.assertIn('TEST_MEMORY_ONLY', json.dumps(requests[0], ensure_ascii=False))
            self.assertIn('tool_result', json.dumps(requests[1]))
            status = (await self.client.get('/relay/app/connection', headers=self.headers)).json()
            self.assertTrue(status['last_memory']['retrieved'])
            forbidden = await rt.loop.Turn('', dry=True).run_tool(rt.loop.tool_public_name('ombre', 'hold'), '{}')
            self.assertTrue(forbidden.startswith('ERROR:'))

    async def test_busy_turn_prevents_second_charge(self):
        await rt.turn_lock.acquire()
        try:
            with patch.dict(os.environ, {'LLM_API_KEY': 'fake-provider-key'}):
                r = await self.client.post('/relay/app/send', headers=self.headers, json={'text': 'second-message'})
                self.assertEqual(r.status_code, 409)
        finally:
            rt.turn_lock.release()


if __name__ == '__main__':
    try:
        unittest.main()
    finally:
        TEST_DATA.cleanup()
