import assert from 'node:assert/strict';
import {chat} from '../cloud/provider.mjs';
const cfg={base_url:'https://linkapi.ai',api_key:'private-model-key',model:'claude-opus-4-6-r',protocol:'anthropic'};
function nativeTool(stop=true){return 'data: '+JSON.stringify({type:'content_block_start',index:0,content_block:{type:'tool_use',id:'c1',name:'ob__hold',input:{}}})+'\n\ndata: '+JSON.stringify({type:'content_block_delta',index:0,delta:{type:'input_json_delta',partial_json:'{"content":"A verified user fact"}'}})+'\n\n'+(stop?'data: {"type":"message_stop"}\n\n':'');}
function nativeReply(text){return 'data: '+JSON.stringify({type:'content_block_start',index:0,content_block:{type:'text',text:''}})+'\n\ndata: '+JSON.stringify({type:'content_block_delta',index:0,delta:{type:'text_delta',text}})+'\n\ndata: {"type":"message_stop"}\n\n';}
function memory(fail=false){const calls=[];return {calls,hasAuth:()=>true,prepare:async q=>({available:true,context:'TEST_ORIGINAL_MEMORY',tools:[{name:'hold',description:'Save a fact',inputSchema:{type:'object',properties:{content:{type:'string'}},required:['content']}}]}),call:async(name,args,options)=>{calls.push({name,args,options});if(fail)throw Error('write status unknown');return '{"ok":true,"bucket_id":"new-id"}';}};}
{
 const mem=memory();const requests=[];const fetcher=async(url,opt)=>{const body=JSON.parse(opt.body);requests.push(body);assert.equal(opt.headers['x-api-key'],cfg.api_key);if(requests.length===1){assert(body.system.includes('TEST_ORIGINAL_MEMORY'));assert.equal(body.tools[0].name,'ob__hold');return new Response(nativeTool());}assert.equal(body.messages.at(-1).content[0].type,'tool_result');assert(body.messages.at(-1).content[0].content.includes('new-id'));return new Response(nativeReply('已保存这条事实。'));};
 const response=await chat(cfg,[{role:'user',content:'请记住这个事实'}],fetcher,mem);const out=await response.text();assert(out.includes('已保存这条事实'));assert(out.includes('"type":"done"'));assert.equal(mem.calls.length,1);assert.equal(mem.calls[0].options.userText,'请记住这个事实');assert(!JSON.stringify(mem.calls).includes(cfg.api_key));
}
{
 const mem=memory();const response=await chat(cfg,[{role:'user',content:'记住'}],async()=>new Response(nativeTool(false)),mem);assert((await response.text()).includes('"type":"error"'));assert.equal(mem.calls.length,0);
}
{
 const mem=memory(true);let count=0;const fetcher=async(url,opt)=>{count++;if(count<=2)return new Response(nativeTool());const body=JSON.parse(opt.body);assert(body.messages.at(-1).content[0].is_error);assert(body.messages.at(-1).content[0].content.includes('未重复写入'));return new Response(nativeReply('保存结果不确定，请先查询。'));};
 const response=await chat(cfg,[{role:'user',content:'记住'}],fetcher,mem);const out=await response.text();assert(out.includes('保存结果不确定'));assert.equal(mem.calls.length,1);
}
{
 const mem=memory();let count=0;const fetcher=async(url,opt)=>{const body=JSON.parse(opt.body);count++;if(count===1){assert.equal(body.tools[0].function.name,'ob__hold');return new Response('data: '+JSON.stringify({choices:[{delta:{tool_calls:[{index:0,id:'o1',function:{name:'ob__hold',arguments:'{"content":"OpenAI route fact"}'}}]}}]})+'\n\ndata: [DONE]\n\n');}assert.equal(body.messages.at(-1).role,'tool');return new Response('data: '+JSON.stringify({choices:[{delta:{content:'Stored with a real tool result.'}}]})+'\n\ndata: [DONE]\n\n');};
 const response=await chat({...cfg,protocol:'openai'},[{role:'user',content:'Remember this'}],fetcher,mem);const out=await response.text();assert(out.includes('Stored with a real tool result.'));assert.equal(mem.calls.length,1);
}
console.log('PASS: retrieved old context, Claude/OpenAI tool rounds, actual write receipts, no execution after truncated stream and no duplicate unknown writes');
