import assert from 'node:assert/strict';
import {chat,chatBody} from '../cloud/provider.mjs';
const cfg={base_url:'https://linkapi.ai',api_key:'fake-key',model:'vision-test',protocol:'anthropic'};
const image='data:image/png;base64,aGVsbG8=';
const messages=[{role:'user',content:[{type:'text',text:'看这张图'},{type:'image_url',image_url:{url:image}}]}];
for(const protocol of ['anthropic','openai']){
 const body=chatBody({...cfg,protocol},messages);const last=body.messages.at(-1);
 assert.equal(last.content[0].text,'看这张图');if(protocol==='anthropic'){assert.equal(last.content[1].type,'image');assert.equal(last.content[1].source.media_type,'image/png');assert.equal(last.content[1].source.data,'aGVsbG8=');}else assert.equal(last.content[1].image_url.url,image);
 let seen=0;const memory={hasAuth:()=>true,prepare:async q=>{assert.equal(q,'看这张图');return {available:true,context:'MOCK_MEMORY',tools:[]};}};
 const response=await chat({...cfg,protocol},messages,async(url,opt)=>{seen++;assert(JSON.parse(opt.body).messages.at(-1).content.length===2);return new Response(protocol==='anthropic'?'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"看到了"}}\n\ndata: {"type":"message_stop"}\n\n':'data: {"choices":[{"delta":{"content":"看到了"}}]}\n\ndata: [DONE]\n\n');},memory);assert((await response.text()).includes('看到了'));assert.equal(seen,1);
}
assert.throws(()=>chatBody(cfg,[{role:'user',content:[{type:'image_url',image_url:{url:'https://other.example/image.png'}}]}]));
{
 const ctl=new AbortController();let called=0;const memory={hasAuth:()=>true,prepare:async()=>new Promise(()=>{})};
 const pending=chat(cfg,[{role:'user',content:'等一下'}],async()=>{called++;},memory,{signal:ctl.signal});ctl.abort();await assert.rejects(pending,e=>e.name==='AbortError');assert.equal(called,0);
}
{
 let cancelled=false;const controller=new AbortController();const response=await chat(cfg,[{role:'user',content:'停止'}],async()=>new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"一部分"}}\n\n'));},cancel(){cancelled=true;}})),null,{signal:controller.signal});const reader=response.body.getReader();await reader.read();controller.abort();await reader.read();assert(cancelled);
}
{
 let calls=0;const ctl=new AbortController(),memory={hasAuth:()=>true,prepare:async()=>({available:true,context:'',tools:[{name:'hold',inputSchema:{type:'object',properties:{content:{type:'string'}}}}]}),call:async()=>{calls++;}};
 const response=await chat(cfg,[{role:'user',content:'记住这个'}],async()=>{ctl.abort();return Response.json({content:[{type:'tool_use',id:'write1',name:'ob__hold',input:{content:'SHOULD_NOT_WRITE'}}]});},memory,{signal:ctl.signal});await response.text();assert.equal(calls,0);
}
console.log('PASS: image blocks for Claude/OpenAI including memory, reject remote image URLs, stop before first model request, abort active stream and prevent later memory writes');
