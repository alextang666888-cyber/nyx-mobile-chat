const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
function storage(){const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),map};}
function phone(){
 const local=storage(),session=storage(),requests=[];
 const window={NYX_BROWSER_ONLY:true,NYX_HOSTED:true,fetch:async(url,opt={})=>{
  requests.push({url,opt});const u=new URL(url);assert.equal(u.origin,'https://linkapi.ai','no credentials or chat may be sent to the website host');
  if(u.pathname==='/v1/models'){assert.equal(opt.headers.get('x-api-key'),'fake-phone-key');assert(!opt.headers.has('Authorization'));return Response.json({data:[{id:'claude-opus-4-6-r'}]});}
  if(u.pathname==='/api/pricing')return Response.json({success:true,usable_group:{default:'Default'},data:[{model_name:'claude-opus-4-6-r',enable_groups:['default'],supported_endpoint_types:['anthropic','openai']}]});
  if(u.pathname==='/v1/messages'){assert.equal(opt.headers.get('x-api-key'),'fake-phone-key');assert.equal(JSON.parse(opt.body).model,'claude-opus-4-6-r');return new Response('data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"DIRECT_REPLY"}}\n\ndata: {"type":"message_stop"}\n\n');}
  throw Error('unexpected external request');
 }};
 const context={window,location:{href:'https://website.example/',origin:'https://website.example'},localStorage:local,sessionStorage:session,URL,URLSearchParams,Response,ReadableStream,AbortController,DOMException,Headers,TextEncoder,TextDecoder,AbortSignal,setInterval,clearInterval,setTimeout,fetch:(...args)=>window.fetch(...args)};
 vm.createContext(context);vm.runInContext(fs.readFileSync('browser-provider.js','utf8'),context);vm.runInContext(fs.readFileSync('hosted-bridge.js','utf8'),context);
 return {window,local,session,requests};
}
(async()=>{
 const a=phone(),b=phone();
 let config=await a.window.fetch('/api/provider').then(r=>r.json());assert.equal(config.key_set,false);assert.equal(a.requests.length,0);
 const entry={base_url:'https://linkapi.ai',api_key:'fake-phone-key'};
 const catalog=await a.window.fetch('/api/provider/discover',{method:'POST',body:JSON.stringify(entry)}).then(r=>r.json());assert.equal(catalog.models[0].id,'claude-opus-4-6-r');assert.equal(catalog.groups[0].id,'default');
 let saved=await a.window.fetch('/api/provider',{method:'POST',body:JSON.stringify({...entry,model:'claude-opus-4-6-r',group:'default',remember:false})}).then(r=>r.json());
 assert.equal(saved.key_set,true);assert.equal(saved.storage,'browser_session');assert(!JSON.stringify(saved).includes('fake-phone-key'));assert(![...a.local.map.values()].some(v=>v.includes('fake-phone-key')));assert([...a.session.map.values()].some(v=>v.includes('fake-phone-key')));
 const other=await b.window.fetch('/api/provider').then(r=>r.json());assert.equal(other.key_set,false);assert.equal(b.requests.length,0);
 const sent=await a.window.fetch('/relay/app/send',{body:JSON.stringify({text:'Hello'})});assert.equal(sent.status,200);
 for(let i=0;i<50;i++){const h=await a.window.fetch('/relay/app/history').then(r=>r.json());if(h.messages.length===2)break;await new Promise(r=>setTimeout(r,10));}
 const history=await a.window.fetch('/relay/app/history').then(r=>r.json());assert.equal(history.messages[1].text,'DIRECT_REPLY');assert.equal((await b.window.fetch('/relay/app/history').then(r=>r.json())).messages.length,0);
 assert.equal(a.requests.filter(r=>new URL(r.url).pathname==='/v1/messages').length,1);assert(a.requests.every(r=>r.opt.credentials==='omit'));
 saved=await a.window.fetch('/api/provider',{method:'POST',body:JSON.stringify({base_url:entry.base_url,model:'claude-opus-4-6-r',remember:true})}).then(r=>r.json());assert.equal(saved.storage,'browser_local');assert([...a.local.map.values()].some(v=>v.includes('fake-phone-key')));assert.equal(a.session.getItem('nyx_direct_api_session_v1'),null);
 console.log('PASS: no login, browser-to-provider requests, models/groups, session-default key storage, optional remember and independent phones/history');
})().catch(e=>{console.error(e);process.exitCode=1;});
