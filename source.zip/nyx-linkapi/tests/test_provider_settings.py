import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import httpx
from fastapi import HTTPException
from provider_settings import ProviderSettings, normalize_base

class ProviderTests(unittest.IsolatedAsyncioTestCase):
    async def test_model_discovery_groups_save_and_key_not_returned(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'test-results') as temp:
            provider=ProviderSettings(temp)
            real_client=httpx.AsyncClient
            requests=[]
            def handler(req):
                requests.append(req)
                if req.url.path=='/v1/models':
                    self.assertEqual(req.headers['Authorization'],'Bearer fake-key-for-tests')
                    return httpx.Response(200,json={'data':[{'id':'claude-opus-4-6-r'},{'id':'gpt-chat'},{'id':'image-only'}]})
                return httpx.Response(200,json={'success':True,'usable_group':{'default':'Default route'},'data':[{'model_name':'claude-opus-4-6-r','enable_groups':['default'],'supported_endpoint_types':['anthropic','openai']},{'model_name':'image-only','supported_endpoint_types':['image-generation']}]})
            def client(**kw):return real_client(transport=httpx.MockTransport(handler),**kw)
            async def public(base):pass
            with patch('provider_settings.httpx.AsyncClient',client),patch('provider_settings.check_public_host',public):
                cfg,catalog=await provider.discover({'base_url':'https://linkapi.ai/v1','api_key':'fake-key-for-tests'})
                self.assertEqual([m['id'] for m in catalog['models']],['claude-opus-4-6-r','gpt-chat'])
                self.assertEqual(catalog['groups'][0]['id'],'default')
                saved=await provider.save({'base_url':'https://linkapi.ai/v1','api_key':'fake-key-for-tests','model':'claude-opus-4-6-r','group':'default'})
                self.assertTrue(saved['key_set'])
                self.assertNotIn('api_key',saved)
                self.assertNotIn('fake-key-for-tests',json.dumps(saved))
                self.assertEqual(provider.current()['protocol'],'anthropic')
                self.assertEqual(ProviderSettings(temp).current()['model'],'claude-opus-4-6-r')
                self.assertEqual(provider.candidate({'base_url':'https://linkapi.ai/v1'})['api_key'],'fake-key-for-tests')
                with self.assertRaises(HTTPException):provider.candidate({'base_url':'https://other.example'})
                with self.assertRaises(HTTPException):await provider.save({'base_url':'https://linkapi.ai/v1','model':'not-authorized'})
            self.assertTrue(all(req.method=='GET' for req in requests))
    async def test_private_or_invalid_origins_rejected(self):
        for base in ['http://linkapi.ai','https://127.0.0.1','https://localhost','https://host.local','https://user:pass@linkapi.ai','https://linkapi.ai/v1/messages','https://linkapi.ai?key=secret']:
            with self.assertRaises(HTTPException,msg=base):normalize_base(base)
        self.assertEqual(normalize_base('https://linkapi.ai/v1/'),'https://linkapi.ai/v1')
