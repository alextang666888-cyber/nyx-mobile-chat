import assert from 'node:assert/strict';
import fs from 'node:fs';
import {chat,chatBody,interactionPrompt} from '../cloud/provider.mjs';
const base=fs.readFileSync('prompts/communication-base.md','utf8').replaceAll('\r\n','\n').trim();
const styles=Object.fromEntries(['chat','scene'].map(n=>[n,fs.readFileSync('prompts/'+n+'.md','utf8').replaceAll('\r\n','\n').trim()]));
assert.equal((base.match(/^[一二三四五六七八]、/gm)||[]).length,8);
const cfg={base_url:'https://linkapi.ai',api_key:'mock-key',model:'test-model'};
for(const protocol of ['anthropic','openai'])for(const mode of ['chat','scene'])for(const memoryState of ['absent','ready','failed']){
 let seen=0;
 const memory=memoryState==='absent'?null:{hasAuth:()=>true,prepare:async()=>({available:memoryState==='ready',failed:memoryState==='failed',context:'MOCK_MEMORY',tools:[]})};
 const fetcher=async(url,opt)=>{try{seen++;const request=JSON.parse(opt.body),system=protocol==='anthropic'?request.system:request.messages[0].content;
  assert(system.includes(base),'long baseline must be complete');assert(system.includes(styles[mode]));assert(!system.includes(styles[mode==='chat'?'scene':'chat']),'only one style');assert(!/虚构|场景创作/.test(system));assert.equal(request.max_tokens,mode==='scene'?3000:2000);assert(system.indexOf(base)<system.indexOf(styles[mode]));if(memoryState==='ready')assert(system.includes('MOCK_MEMORY'));
  const body=protocol==='anthropic'?'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"OK"}}\n\ndata: {"type":"message_stop"}\n\n':'data: {"choices":[{"delta":{"content":"OK"}}]}\n\ndata: [DONE]\n\n';return new Response(body,{headers:{'Content-Type':'text/event-stream'}});}catch(e){console.error(protocol,mode,memoryState,e.message);throw e;}
 };
 const response=await chat({...cfg,protocol},[{role:'user',content:'测试'}],fetcher,memory,{interaction_mode:mode});assert((await response.text()).includes('"type":"done"'));assert.equal(seen,1);
}
assert.equal(interactionPrompt('unknown'),interactionPrompt('chat'));assert(chatBody({...cfg,protocol:'anthropic'},[{role:'user',content:'测试'}]).system.includes(styles.chat));
console.log('PASS: complete eight-section baseline, selected style only, Claude/OpenAI with and without working memory, default chat and no invented history labels');
