const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const crypto=require('node:crypto').webcrypto;
const code=fs.readFileSync('memory.js','utf8');
function store(){const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),map};}
const root='https://alextang666888-cyber.github.io/nyx-mobile-chat/';
function app({local=store(),session=store(),url=root,transport}={}){
 const initial=new URL(url),location={href:url,origin:initial.origin,pathname:initial.pathname,search:initial.search,assign(value){this.assigned=value;}};
 const window=new EventTarget();window.NYX_BROWSER_ONLY=true;window.fetch=transport;
 const history={replaceState(a,b,value){const u=new URL(value,location.href);Object.assign(location,{href:u.href,pathname:u.pathname,search:u.search});}};
 const ctx={window,location,history,localStorage:local,sessionStorage:session,crypto,URL,URLSearchParams,Response,Headers,TextEncoder,TextDecoder,AbortSignal,CustomEvent,btoa,atob,console};vm.createContext(ctx);vm.runInContext(code,ctx);
 return {memory:window.NyxMemory,window,local,session,location};
}
function server(){
 const seen=[],writes=[];let denyOnce=false,failWrite=false,expiredSession=false,reading=0,maxReading=0;
 const available=['pulse','breath','breath_search','hold','grow','trace','breath_advanced','letter_read','shell_exec'].map(name=>({name,description:name,inputSchema:{type:'object',properties:name==='breath_search'?{query:{type:'string'},max_results:{type:'integer'}}:name==='breath_advanced'?{query:{type:'string'},max_tokens:{type:'integer'},max_results:{type:'integer'}}:{}}}));
 const fetch=async(url,opt={})=>{
  assert.equal(new URL(url).origin,'https://ombre-brain-nzh4.onrender.com');seen.push({url,opt});
  if(url.endsWith('/oauth/register'))return Response.json({client_id:'public-client-id'},{status:201});
  if(url.endsWith('/oauth/token')){const body=new URLSearchParams(opt.body);assert.equal(body.get('resource'),'https://ombre-brain-nzh4.onrender.com/mcp');return Response.json({access_token:'new-private-access',refresh_token:'new-private-refresh',expires_in:3600});}
  assert(url.endsWith('/mcp'));assert.equal(opt.credentials,'omit');const request=JSON.parse(opt.body);assert(!JSON.stringify(request).includes('private-access'));
  if(expiredSession&&request.method==='tools/call'){expiredSession=false;return new Response('',{status:404});}
  if(denyOnce&&request.method==='tools/call'){denyOnce=false;return new Response('',{status:401});}
  if(request.method==='notifications/initialized')return new Response(null,{status:202});
  let result;
  if(request.method==='initialize')result={protocolVersion:'2025-03-26',serverInfo:{name:'Mock OB',version:'3.6.2'},capabilities:{tools:{}}};
  if(request.method==='tools/list'){assert.equal(opt.headers['Mcp-Session-Id'],'private-session');result={tools:available};}
  if(request.method==='tools/call'){
   if(request.params.name==='breath_advanced'){reading++;maxReading=Math.max(maxReading,reading);await new Promise(r=>setTimeout(r,12));reading--;}
   if(['hold','grow','trace'].includes(request.params.name)){writes.push(request.params);if(failWrite)throw Error('network interrupted');}
   result={content:[{type:'text',text:request.params.name==='letter_read'?'LETTER_BEGIN'+('原文'.repeat(10000))+'LETTER_END':request.params.arguments?.query==='oversized-auto'?'HUGE_BEGIN'+('X'.repeat(18000))+'HUGE_END':request.params.name==='hold'?JSON.stringify({ok:true,bucket_id:'test-bucket'}):'TEST_OLD_MEMORY'}]};
  }
  const message={jsonrpc:'2.0',id:request.id,result};
  if(request.method==='tools/call')return new Response('event: message\r\ndata: '+JSON.stringify(message)+'\r\n\r\n',{headers:{'Content-Type':'text/event-stream'}});
  return Response.json(message,{headers:{'Mcp-Session-Id':'private-session'}});
 };
 return {fetch,seen,writes,deny(){denyOnce=true;},fail(){failWrite=true;},expire(){expiredSession=true;},parallel(){return maxReading;}};
}
(async()=>{
 const s=server(),a=app({transport:s.fetch});assert.equal(a.memory.hasAuth(),false);
 await a.memory.connect();const authorize=new URL(a.location.assigned),pending=JSON.parse(a.session.getItem('nyx_ob_pending_v1'));assert.equal(authorize.origin,'https://ombre-brain-nzh4.onrender.com');assert.equal(authorize.searchParams.get('code_challenge_method'),'S256');assert.equal(authorize.searchParams.get('state'),pending.state);assert(!a.location.assigned.includes(pending.verifier));assert.equal(authorize.searchParams.get('redirect_uri'),root);
 const returned=app({local:a.local,session:a.session,url:root+'?code=private-code&state='+encodeURIComponent(pending.state),transport:s.fetch});
 await returned.memory.callback;assert(returned.memory.status().ready);assert(!returned.location.href.includes('private-code'));assert.equal(returned.memory.status().tools.includes('shell_exec'),false);
 const prepared=await returned.memory.prepare('shared history');assert(prepared.available);assert(prepared.context.includes('TEST_OLD_MEMORY'));assert(returned.memory.status().lastRead);assert.equal(s.parallel(),2,'first core and related reads should overlap');
 const letter=await returned.memory.letters('信件标题');assert(letter.startsWith('LETTER_BEGIN'));assert(letter.endsWith('LETTER_END'));assert(letter.length>14000);assert(s.seen.some(x=>x.opt.body&&x.opt.body.includes('letter_read')));
 const oversized=await returned.memory.prepare('oversized-auto');assert(oversized.limited);assert(!oversized.context.includes('HUGE_BEGIN'));assert(oversized.context.includes('未截断正文'));assert(returned.memory.status().retrieveMs>=0);assert(returned.memory.status().contextChars===oversized.context.length);
 await returned.memory.call('hold',{content:'explicit test only'},{userText:'保存这条记忆'});assert(returned.memory.status().lastWrite);assert.equal(s.writes.length,1);
 await assert.rejects(()=>returned.memory.call('trace',{delete:true},{userText:'hello'}),/删除记忆需要/);assert.equal(s.writes.length,1);
 await returned.memory.call('trace',{delete:true},{userText:'删除这条测试记忆'});assert.equal(s.writes.length,2);
 s.deny();await returned.memory.call('pulse',{});assert(s.seen.some(x=>x.url.endsWith('/oauth/token')&&new URLSearchParams(x.opt.body).get('grant_type')==='refresh_token'));
 s.expire();await assert.rejects(()=>returned.memory.call('pulse',{}),/HTTP 404/);assert.equal(returned.memory.status().ready,false);await returned.memory.call('pulse',{});assert(returned.memory.status().ready);
 await assert.rejects(()=>returned.memory.call('trace',{hard_delete:true},{userText:'hello'}),/删除记忆需要/);
 s.fail();const previous=s.writes.length;await assert.rejects(()=>returned.memory.call('hold',{content:'no duplicate'}));assert.equal(s.writes.length,previous+1);assert.equal(returned.memory.status().lastWrite,false);
 const noAuth=app({transport:s.fetch});assert.equal(noAuth.memory.hasAuth(),false);
 const invalidSession=store();invalidSession.setItem('nyx_ob_pending_v1',JSON.stringify({state:'expected',created:Date.now(),redirect:root}));const before=s.seen.length;
 const invalid=app({session:invalidSession,url:root+'?code=not-used&state=wrong',transport:s.fetch});await invalid.memory.callback;assert(invalid.memory.status().error.includes('回调无效'));assert.equal(s.seen.length,before);
 returned.memory.disconnect();assert.equal(returned.memory.hasAuth(),false);assert.equal(returned.local.getItem('nyx_ob_auth_v1'),null);
 console.log('PASS: private PKCE callback, state check, MCP initialize/session/SSE, retrieval, write/update, explicit-delete guard, refresh, no write retry and device isolation');
})().catch(e=>{console.error(e);process.exitCode=1;});
