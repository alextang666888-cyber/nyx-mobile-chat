const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
(async()=>{
const data=new Map();let calls=0;
const realFetch=async(url,opt)=>{
 if(url==='/api/provider')return Response.json({key_set:true,model:'claude-opus-4-6-r'});
 if(url==='/api/chat'){calls++;assert.equal(JSON.parse(opt.body).messages.at(-1).content,'real-user-message');return new Response('data: {"type":"text","text":"MOCK_REAL_REPLY"}\n\ndata: {"type":"done"}\n\n');}
 throw Error('unexpected request');
};
const window={NYX_HOSTED:true,fetch:realFetch};const sandbox={window,location:{href:'https://site.example/',origin:'https://site.example'},localStorage:{getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)},URL,URLSearchParams,Response,ReadableStream,AbortController,DOMException,TextEncoder,TextDecoder,setInterval,clearInterval,setTimeout};vm.createContext(sandbox);vm.runInContext(fs.readFileSync('hosted-bridge.js','utf8'),sandbox);
const streamReader=(await window.fetch('/relay/app/stream')).body.getReader();
const response=await window.fetch('/relay/app/send',{body:JSON.stringify({text:'real-user-message'})});assert.equal(response.status,200);
for(let i=0;i<50;i++){const h=await window.fetch('/relay/app/history').then(r=>r.json());if(h.messages.length===2)break;await new Promise(r=>setTimeout(r,10));}
const history=await window.fetch('/relay/app/history').then(r=>r.json());assert.equal(history.messages.length,2);assert.equal(history.messages[1].text,'MOCK_REAL_REPLY');assert.equal(calls,1);const events=[];while(!events.some(e=>e.from==='ai')){const chunk=await streamReader.read();for(const line of new TextDecoder().decode(chunk.value).split('\n'))if(line.startsWith('data:'))events.push(JSON.parse(line.slice(5)));}await streamReader.cancel();const delta=events.find(e=>e.type==='reply_delta'),final=events.find(e=>e.from==='ai');assert(delta&&final.meta.stream_id===delta.stream_id);assert.equal(history.messages[1].meta.stream_id,delta.stream_id);assert(![...data.values()].some(s=>s.includes('api_key')));console.log('PASS: hosted chat sends actual request, consumes stream, persists conversation, stores no API key');
})().catch(e=>{console.error(e);process.exitCode=1;});
