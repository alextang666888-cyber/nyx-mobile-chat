const {chromium}=require('D:/CodexProjects/.cache/nyx-ui-qa/node_modules/playwright-core');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const output='D:/CodexProjects/outputs/nyx-memory-qa';fs.mkdirSync(output,{recursive:true});
const OB='https://ombre-brain-nzh4.onrender.com',ROOT='http://127.0.0.1:8089/';
(async()=>{
 const context=await chromium.launchPersistentContext('D:/CodexProjects/user-temp/nyx-memory-qa-'+Date.now(),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true,viewport:{width:360,height:740},isMobile:true,hasTouch:true,args:['--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-breakpad','--disable-crash-reporter','--disable-sync'],env:{...process.env,TEMP:'D:/CodexProjects/user-temp',TMP:'D:/CodexProjects/user-temp'}});
 const errors=[],calls=[],modelRequests=[];let value='MOCK_OLD_MEMORY',modelRound=0;
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.route('https://cdn.jsdelivr.net/**',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
 const tools=['pulse','breath','breath_search','hold','grow','trace','letter_read'].map(name=>({name,description:name,inputSchema:{type:'object',properties:name==='trace'?{bucket_id:{type:'string'},content:{type:'string'}}:{content:{type:'string'},query:{type:'string'}}}}));
 await page.route(OB+'/**',async route=>{
  const req=route.request(),url=req.url();const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Expose-Headers':'Mcp-Session-Id','Mcp-Session-Id':'mock-browser-session'};
  if(req.method()==='OPTIONS')return route.fulfill({status:200,headers});
  if(url.includes('/oauth/register'))return route.fulfill({status:201,headers,json:{client_id:'mock-browser-public-client'}});
  if(url.includes('/oauth/authorize'))return route.fulfill({status:200,body:'<title>Mock authorization</title><p>Mock authorization only</p>',contentType:'text/html'});
  if(url.includes('/oauth/token'))return route.fulfill({status:200,headers,json:{access_token:'mock-private-memory-access',refresh_token:'mock-private-memory-refresh',expires_in:3600}});
  assert.equal(url,OB+'/mcp');assert(!req.postData().includes('mock-private-model-key'));assert.equal(req.headers().authorization,'Bearer mock-private-memory-access');
  const body=req.postDataJSON();if(body.method==='notifications/initialized')return route.fulfill({status:202,headers});
  let result;
  if(body.method==='initialize')result={protocolVersion:'2025-03-26',serverInfo:{name:'Mock OB',version:'3.6.2'},capabilities:{tools:{}}};
  else if(body.method==='tools/list')result={tools};
  else if(body.method==='tools/call'){
   calls.push(body.params);const {name,arguments:args}=body.params;
   if(name==='hold'||name==='trace')value=args.content;
   result={content:[{type:'text',text:name==='letter_read'?'LETTER_BEGIN'+('原文'.repeat(9000))+'LETTER_END':name==='hold'||name==='trace'?JSON.stringify({ok:true,bucket_id:'mock-bucket'}):value}]};
  }else throw Error('Unexpected MCP method: '+body.method);
  return route.fulfill({status:200,headers,contentType:'text/event-stream',body:'event: message\r\ndata: '+JSON.stringify({jsonrpc:'2.0',id:body.id,result})+'\r\n\r\n'});
 });
 await page.route('https://linkapi.ai/**',async route=>{
  const req=route.request();if(req.method()==='OPTIONS')return route.fulfill({status:200,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*'}});
  assert(req.url().endsWith('/v1/messages'));const body=req.postDataJSON();assert(!req.postData().includes('mock-private-memory-access'));assert(!req.postData().includes('mock-private-memory-refresh'));assert.equal(req.headers()['x-api-key'],'mock-private-model-key');modelRequests.push(body);
  const update=body.messages.some(m=>typeof m.content==='string'&&m.content.includes('更新这条记忆'));
  const last=body.messages.at(-1);const receipt=Array.isArray(last.content)&&last.content.some(b=>b.type==='tool_result');let events;
  if(!receipt){assert(body.system.includes(value));const args=update?{bucket_id:'mock-bucket',content:'MOCK_UPDATED_BY_CHAT'}:{content:'MOCK_SAVED_BY_CHAT'};events=[{type:'content_block_start',index:0,content_block:{type:'tool_use',id:'mock-call-'+(++modelRound),name:update?'ob__trace':'ob__hold',input:{}}},{type:'content_block_delta',index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify(args)}},{type:'message_stop'}];}
  else{assert(last.content[0].content.includes('mock-bucket'));events=[{type:'content_block_start',index:0,content_block:{type:'text',text:''}},{type:'content_block_delta',index:0,delta:{type:'text_delta',text:update?'已更新测试记忆。':'已保存测试记忆。'}},{type:'message_stop'}];}
  return route.fulfill({status:200,headers:{'Access-Control-Allow-Origin':'*'},contentType:'text/event-stream',body:events.map(e=>'data: '+JSON.stringify(e)+'\n\n').join('')});
 });
 await page.addInitScript(()=>{sessionStorage.setItem('nyx_direct_api_session_v1',JSON.stringify({base_url:'https://linkapi.ai',api_key:'mock-private-model-key',model:'claude-opus-4-6-r',protocol:'anthropic'}));});
 try{
  await page.goto(ROOT+'#chat');await page.click('#memoryOpen');await page.click('#memoryConnect');await page.waitForURL(OB+'/oauth/authorize?**');
  const target=new URL(page.url());assert.equal(target.searchParams.get('code_challenge_method'),'S256');assert.equal(target.searchParams.get('redirect_uri'),ROOT);const state=target.searchParams.get('state');assert(state);assert(!page.url().includes('mock-private-memory-access'));
  await page.goto(ROOT+'?code=mock-test-code&state='+encodeURIComponent(state));await page.waitForFunction(()=>window.NyxMemory?.status().ready);assert(!page.url().includes('mock-test-code'));await page.click('#memoryOpen');
  await page.fill('#memoryQuery','old memory');await page.click('#memorySearch');await page.waitForFunction(()=>document.querySelector('#memoryResult').textContent==='MOCK_OLD_MEMORY');
  await page.click('#memoryLetters');await page.waitForFunction(()=>document.querySelector('#memoryResult').textContent.endsWith('LETTER_END'));assert((await page.locator('#memoryResult').innerText()).length>14000);
  await page.fill('#memoryContent','MOCK_MANUAL_SAVE <img src=x onerror=alert(1)>');await page.click('#memorySave');await page.waitForFunction(()=>document.querySelector('#memoryResult').textContent.includes('mock-bucket'));
  await page.click('#memorySearch');await page.waitForFunction(()=>document.querySelector('#memoryResult').textContent.includes('MOCK_MANUAL_SAVE'));assert.equal(await page.locator('#memoryResult img').count(),0);assert.equal(calls.filter(c=>c.name==='hold').length,1);
  for(const [width,height] of [[320,640],[360,740],[412,915]]){await page.setViewportSize({width,height});await page.waitForTimeout(180);const g=await page.locator('#memoryDialog').boundingBox();assert(g.x>=0&&g.x+g.width<=width+1&&g.y>=0&&g.y+g.height<=height+1);}
  await page.setViewportSize({width:360,height:740});await page.screenshot({path:path.join(output,'memory-panel.png')});await page.focus('#memoryContent');await page.setViewportSize({width:360,height:390});await page.waitForTimeout(300);
  const g=await page.locator('#memoryDialog').boundingBox();assert(g.y>=0&&g.y+g.height<=391);const input=await page.locator('#memoryContent').boundingBox();assert(input.y>=g.y&&input.y+input.height<=g.y+g.height,'memory textarea hidden by keyboard');await page.screenshot({path:path.join(output,'memory-keyboard.png')});
  await page.click('#memoryClose');await page.setViewportSize({width:360,height:740});await page.fill('#text','请记住这个测试事实');await page.click('#send');await page.waitForFunction(()=>document.querySelector('#log').textContent.includes('已保存测试记忆。'));assert.equal(calls.filter(c=>c.name==='hold').length,2);
  await page.fill('#text','更新这条记忆为测试新内容');await page.click('#send');await page.waitForFunction(()=>document.querySelector('#log').textContent.includes('已更新测试记忆。'));assert.equal(calls.filter(c=>c.name==='trace').length,1);
  await page.click('#memoryOpen');await page.click('#memorySearch');await page.waitForFunction(()=>document.querySelector('#memoryResult').textContent==='MOCK_UPDATED_BY_CHAT');await page.screenshot({path:path.join(output,'memory-chat-update.png')});
  await page.click('#memoryDisconnect');assert(await page.locator('#memoryFunctions').isHidden());assert.equal(await page.evaluate(()=>localStorage.getItem('nyx_ob_auth_v1')),null);assert.equal(errors.length,0,JSON.stringify(errors));
  const report={passed:true,mockOnly:true,oauthPKCE:true,callbackClean:true,manualSave:true,queryAfterSave:true,chatSave:true,chatUpdate:true,credentialIsolation:true,deviceDisconnect:true,mobileWidths:[320,360,412],keyboardHeight:390,mcpCalls:calls.map(c=>c.name),modelRequests:modelRequests.length,errors};fs.writeFileSync(path.join(output,'browser-report.json'),JSON.stringify(report,null,2));console.log('PASS: Edge browser PKCE roundtrip, MCP SSE, manual save/query, chat save/update, credential isolation, mobile dialog and keyboard; mock data only');
 }finally{await context.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
