"""Create inspectable source and deployment ZIPs; never include secrets or runtime data."""
import hashlib
import json
import sys
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT.parent/'outputs'
OUTPUT.mkdir(exist_ok=True)
EXCLUDED_DIRS={'.cloud-build','.git','.venv','data','__pycache__','test-results','preview-site','node_modules','.openai'}
EXCLUDED_FILES={'source.zip','.env','api_loop.config.json','relay.env'}

def source_files():
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in rel.parts) or not path.is_file():
            continue
        if path.name in EXCLUDED_FILES or path.suffix in {'.pyc','.db','.pem','.key'}:
            continue
        yield path, rel.as_posix()

files=list(source_files())
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for path,name in files}
source=ROOT/'source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for path,name in files:z.write(path,'nyx-linkapi/'+name)
    z.writestr('nyx-linkapi/SOURCE_SHA256.json',json.dumps(manifest,indent=2,ensure_ascii=False))
starter=OUTPUT/(sys.argv[1] if len(sys.argv)>1 else 'nyx-linkapi-starter.zip')
with zipfile.ZipFile(starter,'w',zipfile.ZIP_DEFLATED) as z:
    for path,name in files:z.write(path,'nyx-linkapi/'+name)
    z.write(source,'nyx-linkapi/source.zip')
    z.writestr('nyx-linkapi/SOURCE_SHA256.json',json.dumps(manifest,indent=2,ensure_ascii=False))
with zipfile.ZipFile(starter) as z:
    bad=[n for n in z.namelist() if '/data/' in n or '/.venv/' in n or n.endswith('/.env')]
    if bad:raise RuntimeError('Private data in archive: '+repr(bad))
    assert 'nyx-linkapi/runtime.py' in z.namelist()
    assert 'nyx-linkapi/api/anthropic_adapter.py' in z.namelist()
    assert 'nyx-linkapi/source.zip' in z.namelist()
    assert z.testzip() is None
print(json.dumps({'archive':str(starter),'bytes':starter.stat().st_size,'sha256':hashlib.sha256(starter.read_bytes()).hexdigest(),'source_files':len(files)},ensure_ascii=False))
