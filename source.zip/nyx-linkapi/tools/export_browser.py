from pathlib import Path
import json
import shutil
import zipfile
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'preview-site'
DEST=ROOT.parent/'nyx-browser'
if DEST.exists() and not (DEST/'NYX_BROWSER_EXPORT.txt').exists():
    raise SystemExit('Destination exists without our export marker; refusing to overwrite')
DEST.mkdir(exist_ok=True)
(DEST/'NYX_BROWSER_EXPORT.txt').write_text('Nyx browser-only export. No backend required.\n',encoding='utf-8')
names=['index.html','app.css','app.js','config.js','paper.js','home.js','water.js','tree.js','hold.js','startup.js','startup.css','browser-provider.js','browser-media.js','memory.js','memory-ui.js','memory.css','interaction.js','interaction.css','mobile.js','mobile.css','settings.js','settings.css','hosted-bridge.js','demo.js','sw.js','manifest.webmanifest','icon-180.png','icon-192.png','icon-512.png','star.svg','LICENSE','source.zip']
for name in names:shutil.copy2(ROOT/name,DEST/name)
shutil.copytree(ROOT/'fonts',DEST/'fonts',dirs_exist_ok=True)
(DEST/'config.js').write_text('window.NYX_HOSTED=true;window.NYX_BROWSER_ONLY=true;window.NYX_PREVIEW_ONLY=false;\n'+(ROOT/'config.js').read_text(encoding='utf-8'),encoding='utf-8')
shutil.copy2(ROOT/'api/LICENSE',DEST/'PROVIDER_LICENSE.txt')
(DEST/'credits.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Nyx · 来源</title><body style="max-width:650px;margin:60px auto;padding:24px;font:16px/1.9 system-ui;background:#ece8e1;color:#453f35"><h1>Nyx · 纯前端版</h1><p>界面基于 <a href="https://github.com/StarFold146/Nyx">StarFold146 / Nyx</a>，采用 <a href="LICENSE">CC BY-NC 4.0</a>，仅限非商业使用。</p><p>本版简化导航，新增中文 API 设置、模型目录选择与浏览器直连。无需网站账号，不运行聊天中转后端。</p><p>API 适配代码采用 <a href="PROVIDER_LICENSE.txt">AGPL-3.0</a>。<a href="source.zip">完整对应源码</a>；浏览器运行代码也以可读 JavaScript 提供。</p><a href="./">返回聊天</a></body></html>',encoding='utf-8')
shutil.copy2(ROOT/'README_开始使用.md',DEST/'README.md')
shutil.copy2(ROOT/'docs/PROJECT_STATUS.md',DEST/'PROJECT_STATUS.md')
public=SITE/'public'
shutil.copytree(DEST,public,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git'))
manifest_path=SITE/'.openai/hosting.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'));manifest['static']={'directory':'out'};manifest['d1']=None;manifest['r2']=None
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=ROOT.parent/'outputs/nyx-browser-no-login.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(DEST.rglob('*')):
        if p.is_file() and '.git' not in p.relative_to(DEST).parts:z.write(p,p.relative_to(DEST).as_posix())
with zipfile.ZipFile(archive) as z:
    assert 'index.html' in z.namelist() and 'browser-provider.js','browser-media.js' in z.namelist()
    assert 'runtime.py' not in z.namelist() and '.env' not in z.namelist()
    assert z.testzip() is None
print(json.dumps({'directory':str(DEST),'archive':str(archive),'bytes':archive.stat().st_size}))
