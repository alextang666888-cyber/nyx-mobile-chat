from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'preview-site'
public=SITE/'public';public.mkdir(exist_ok=True)
names=['index.html','app.css','app.js','config.js','paper.js','home.js','water.js','tree.js','hold.js','startup.js','startup.css','browser-provider.js','browser-media.js','memory.js','memory-ui.js','memory.css','interaction.js','interaction.css','history.js','history.css','mobile.js','mobile.css','settings.js','settings.css','hosted-bridge.js','demo.js','sw.js','manifest.webmanifest','icon-180.png','icon-192.png','icon-512.png','star.svg','credits.html','LICENSE','source.zip']
for name in names:shutil.copy2(ROOT/name,public/name)
shutil.copytree(ROOT/'fonts',public/'fonts',dirs_exist_ok=True)
worker=SITE/'worker';worker.mkdir(exist_ok=True)
shutil.copy2(ROOT/'cloud/provider.mjs',worker/'provider.mjs')
shutil.copy2(ROOT/'cloud/prompts.mjs',worker/'prompts.mjs')
shutil.copy2(ROOT/'cloud/worker.mjs',worker/'index.mjs')
print('Cloud sources and assets synchronized without secrets.')
