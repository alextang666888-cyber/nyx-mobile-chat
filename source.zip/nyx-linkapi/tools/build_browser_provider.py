"""Compile reviewed UTF-8 presets into the shared provider and browser bundle."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
base=(ROOT/'prompts/communication-base.md').read_text(encoding='utf-8').strip()
modes={name:(ROOT/('prompts/'+name+'.md')).read_text(encoding='utf-8').strip() for name in ('chat','scene')}
compiled='// Generated from prompts/*.md; edit the Markdown originals. AGPL-3.0.\n'
compiled+='export const COMMUNICATION_BASE='+json.dumps(base,ensure_ascii=False)+';\n'
compiled+='export const INTERACTION_MODES='+json.dumps(modes,ensure_ascii=False)+';\n'
(ROOT/'cloud/prompts.mjs').write_text(compiled,encoding='utf-8')
shared=(ROOT/'cloud/provider.mjs').read_text(encoding='utf-8').replace("import {COMMUNICATION_BASE,INTERACTION_MODES} from './prompts.mjs';",'').replace('export ','')
bootstrap=(ROOT/'cloud/browser-bootstrap.js').read_text(encoding='utf-8')
(ROOT/'browser-provider.js').write_text('/* Generated from prompts/*.md, cloud/provider.mjs and cloud/browser-bootstrap.js; AGPL-3.0. */\n(function(){\n'+compiled.replace('export ','')+'\n'+shared+'\n'+bootstrap+'\n})();\n',encoding='utf-8')
print('Built reviewed prompts and browser-only provider transport.')
