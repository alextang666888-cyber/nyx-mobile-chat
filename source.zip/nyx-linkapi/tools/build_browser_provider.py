from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
shared=(ROOT/'cloud/provider.mjs').read_text(encoding='utf-8').replace('export ','')
bootstrap=(ROOT/'cloud/browser-bootstrap.js').read_text(encoding='utf-8')
(ROOT/'browser-provider.js').write_text('/* Generated from cloud/provider.mjs and cloud/browser-bootstrap.js; AGPL-3.0. */\n(function(){\n'+shared+'\n'+bootstrap+'\n})();\n',encoding='utf-8')
print('Built browser-only provider transport.')
