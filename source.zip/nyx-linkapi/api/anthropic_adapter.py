"""Claude Messages transport for the Tidal Echo API loop (AGPL-3.0)."""
import base64
import json
import httpx


def endpoint(base):
    base = base.rstrip('/')
    if base.endswith('/messages'):
        return base
    return base + ('/messages' if base.endswith('/v1') else '/v1/messages')


def blocks(content):
    if isinstance(content, str):
        return [{'type': 'text', 'text': content}] if content else []
    out = []
    for part in content or []:
        if part.get('type') == 'text':
            out.append({'type': 'text', 'text': part.get('text', '')})
        elif part.get('type') == 'image_url':
            url = part['image_url']['url']
            if url.startswith('data:') and ';base64,' in url:
                mime, data = url[5:].split(';base64,', 1)
                base64.b64decode(data, validate=True)
                out.append({'type': 'image', 'source': {'type': 'base64', 'media_type': mime, 'data': data}})
            else:
                raise ValueError('Only uploaded base64 images are supported')
    return out


def request_body(route, messages, tools, max_tokens, stream):
    system, converted = [], []
    for msg in messages:
        role = msg['role']
        if role == 'system':
            system.extend(blocks(msg.get('content')))
            continue
        if role == 'tool':
            role = 'user'
            content = [{'type': 'tool_result', 'tool_use_id': msg['tool_call_id'], 'content': msg.get('content') or '(empty result)'}]
        else:
            content = blocks(msg.get('content'))
            for call in msg.get('tool_calls') or []:
                fn = call['function']
                content.append({'type': 'tool_use', 'id': call['id'], 'name': fn['name'], 'input': json.loads(fn.get('arguments') or '{}')})
        if not content:
            continue
        if converted and converted[-1]['role'] == role:
            converted[-1]['content'].extend(content)
        else:
            converted.append({'role': role, 'content': content})
    body = {'model': route['model'], 'max_tokens': max_tokens, 'messages': converted, 'stream': stream}
    if system:
        body['system'] = system
    if tools:
        body['tools'] = [{'name': t['function']['name'], 'description': t['function'].get('description', ''), 'input_schema': t['function']['parameters']} for t in tools]
    return body


async def complete(route, messages, tools, *, max_tokens, stream, sink, error_type, transport=None):
    body = request_body(route, messages, tools, max_tokens, stream)
    headers = {'x-api-key': route['key'], 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json'}
    async with httpx.AsyncClient(timeout=httpx.Timeout(180, connect=20), transport=transport) as client:
        async with client.stream('POST', endpoint(route['url']), headers=headers, json=body) as resp:
            if resp.status_code >= 300:
                # Do not echo provider response bodies: some gateways reflect secrets.
                await resp.aread()
                raise error_type(resp.status_code, f'LinkAPI HTTP {resp.status_code}; check model access, balance and route', route)
            if not stream:
                data = json.loads(await resp.aread())
                text = ''.join(b.get('text', '') for b in data.get('content', []) if b.get('type') == 'text')
                calls = [{'id': b['id'], 'name': b['name'], 'arguments': json.dumps(b.get('input', {}), ensure_ascii=False)} for b in data.get('content', []) if b.get('type') == 'tool_use']
                if not text and not calls:
                    raise error_type(502, 'Claude returned no text or tool calls', route)
                return {'text': text, 'thinking': '', 'tool_calls': calls, 'usage': data.get('usage', {})}
            text, calls, usage = [], {}, {}
            stopped = False
            async for line in resp.aiter_lines():
                if not line.startswith('data:'):
                    continue
                ev = json.loads(line[5:].strip())
                kind = ev.get('type')
                if kind == 'error':
                    raise error_type(502, 'Claude stream returned an error', route)
                if kind == 'message_start':
                    usage.update(ev.get('message', {}).get('usage') or {})
                elif kind == 'content_block_start':
                    block = ev.get('content_block') or {}
                    if block.get('type') == 'tool_use':
                        calls[ev['index']] = {'id': block['id'], 'name': block['name'], 'arguments': '', '_input': block.get('input', {})}
                    elif block.get('type') == 'text' and block.get('text'):
                        text.append(block['text'])
                        await sink(block['text'])
                elif kind == 'content_block_delta':
                    delta = ev.get('delta') or {}
                    if delta.get('type') == 'text_delta':
                        chunk = delta.get('text', '')
                        text.append(chunk)
                        await sink(chunk)
                    elif delta.get('type') == 'input_json_delta' and ev['index'] in calls:
                        calls[ev['index']]['arguments'] += delta.get('partial_json', '')
                    # Thinking/signature blocks are intentionally not exposed as chat text.
                elif kind == 'message_delta':
                    usage.update(ev.get('usage') or {})
                elif kind == 'message_stop':
                    stopped = True
            if not stopped:
                raise error_type(502, 'Claude stream ended early; reply may be incomplete', route)
            for call in calls.values():
                initial = call.pop('_input')
                call['arguments'] = call['arguments'] or json.dumps(initial, ensure_ascii=False)
                json.loads(call['arguments'])
            if not text and not calls:
                raise error_type(502, 'Claude returned no text or tool calls', route)
            return {'text': ''.join(text), 'thinking': '', 'tool_calls': list(calls.values()), 'usage': usage}
