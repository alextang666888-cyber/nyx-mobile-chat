"""Authenticated provider discovery and server-side API settings (AGPL-3.0)."""
import asyncio
import contextlib
import ipaddress
import json
import os
import socket
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit
import httpx
from fastapi import HTTPException


def normalize_base(value):
    value = str(value or '').strip().rstrip('/')
    try:
        u = urlsplit(value)
        if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.port not in (None,443):
            raise ValueError()
        if u.path not in ('','/v1'):
            raise ValueError()
        host = u.hostname.lower()
        if '.' not in host or host.endswith(('.local','.localhost','.internal')):
            raise ValueError()
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            raise ValueError()
        return urlunsplit(('https',u.netloc.lower(),u.path,'',''))
    except (ValueError,TypeError):
        raise HTTPException(400,'请填写服务商 HTTPS 地址，可带 /v1；不要填写具体模型接口。') from None


async def check_public_host(base):
    try:
        rows = await asyncio.to_thread(socket.getaddrinfo,urlsplit(base).hostname,443,type=socket.SOCK_STREAM)
        if not rows or any(not ipaddress.ip_address(row[4][0]).is_global for row in rows):
            raise ValueError()
    except (OSError,ValueError):
        raise HTTPException(400,'服务商地址无法解析为公开网络地址。') from None


class ProviderSettings:
    def __init__(self, directory):
        self.path = Path(directory)/'provider-settings.json'
    def current(self):
        if self.path.exists():
            try:
                return json.loads(self.path.read_text(encoding='utf-8'))
            except (OSError,ValueError):
                raise HTTPException(503,'API 设置文件读取失败，请先检查服务器存储。') from None
        return {'base_url':os.environ.get('LLM_API_BASE','https://linkapi.ai'),'api_key':os.environ.get('LLM_API_KEY','').strip(),'model':os.environ.get('LLM_MODEL','claude-opus-4-6-r'),'protocol':os.environ.get('LLM_PROTOCOL','anthropic'),'group':''}
    def public(self):
        cfg=self.current()
        return {k:cfg.get(k,'') for k in ('base_url','model','protocol','group')} | {'key_set':bool(cfg.get('api_key')),'storage':'server'}
    def candidate(self,body):
        base=normalize_base(body.get('base_url'))
        old=self.current()
        key=str(body.get('api_key') or '').strip()
        if not key and normalize_base(old.get('base_url'))==base:
            key=old.get('api_key','')
        if not key or len(key)>2048 or any(c in key for c in '\r\n'):
            raise HTTPException(400,'请输入 API key；更换服务商网址时需要重新填写。')
        return {'base_url':base,'api_key':key}
    async def discover(self,body):
        cfg=self.candidate(body)
        await check_public_host(cfg['base_url'])
        origin=cfg['base_url'].removesuffix('/v1')
        async with httpx.AsyncClient(timeout=25,follow_redirects=False,trust_env=False) as client:
            try:
                resp=await client.get(origin+'/v1/models',headers={'Authorization':'Bearer '+cfg['api_key']})
                if resp.status_code!=200:
                    raise HTTPException(400,f'读取模型失败（HTTP {resp.status_code}），请检查密钥和服务商权限。')
                data=resp.json()
                if not isinstance(data.get('data'),list):raise ValueError()
                ids=sorted({m['id'] for m in data['data'] if isinstance(m,dict) and isinstance(m.get('id'),str)})[:3000]
            except HTTPException:raise
            except Exception:
                raise HTTPException(502,'读取模型失败，请检查服务商地址和网络。') from None
            metadata={}; groups={}
            try:
                pricing=(await client.get(origin+'/api/pricing')).json()
                if pricing.get('success'):
                    metadata={m['model_name']:m for m in pricing.get('data',[]) if isinstance(m,dict) and isinstance(m.get('model_name'),str)}
                    groups=pricing.get('usable_group') or {}
            except Exception:pass
        models=[]
        used_groups=set()
        for model in ids:
            meta=metadata.get(model,{})
            endpoints=meta.get('supported_endpoint_types') or []
            if endpoints and not set(endpoints)&{'anthropic','openai'}:continue
            gs=[g for g in meta.get('enable_groups',[]) if isinstance(g,str)]
            used_groups.update(gs)
            models.append({'id':model,'groups':gs,'protocol':'anthropic' if 'anthropic' in endpoints or (not endpoints and 'claude' in model.lower()) else 'openai'})
        return cfg,{'models':models,'groups':[{'id':g,'label':str(groups.get(g) or g)} for g in sorted(used_groups)],'group_mode':'catalog_filter','notice':'分组用于筛选模型；实际计费分组由服务商为这把 API key 设置的权限决定。'}
    async def save(self,body):
        cfg,catalog=await self.discover(body)
        selected=next((m for m in catalog['models'] if m['id']==body.get('model')),None)
        if not selected:raise HTTPException(400,'请选择这把 API key 返回的可用模型。')
        cfg.update(model=selected['id'],protocol=selected['protocol'],group=str(body.get('group') or ''))
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(cfg,ensure_ascii=False),encoding='utf-8')
        with contextlib.suppress(OSError):tmp.chmod(0o600)
        tmp.replace(self.path)
        return self.public()
