# Changes for the personal LinkAPI starter

2026-11-11:
- Retained Nyx UI; simplified app navigation; added Chinese connection labels, explicit demo mode, and model/memory status.
- Added native Anthropic Messages conversion, streaming parser, tool-result conversion, premature-stream detection, and conservative request limits.
- Added single-process runtime joining Nyx Relay and the Tidal Echo API loop through in-process forwarding.
- Added opt-in remote OB MCP retrieval, limited tool allowlist and disabled long-term writes by default.
- Disabled optional desktop command/control plugins in minimal mode; restricted exposed relay routes; keep secrets out of static files.
- Fixed deterministic SQLite connection closure, disabled promotion of reasoning content into visible replies.
- Added functional checks, personal VPS examples and source distribution. No existing OB database was touched.

Backend additions: AGPL-3.0. Frontend changes retain the upstream CC BY-NC 4.0 license. Upstream attribution and license files remain included.

API settings update (2026-11-11):
- Added website-based provider URL/key entry, authenticated model discovery, optional public group catalog, model search/dropdown and saved selection.
- Group selection is a catalog filter, not an unauthorized billing-route override.
- Added hosted Worker transport with encrypted HttpOnly device settings cookie and device-local chat history. VPS mode retains server-side settings/history.
- OB remains backend-only; no memory settings panel or live OB changes.

Browser-only public update (2026-11-11):
- Removed website-account requirement from the main static experience.
- Browser directly fetches provider model/catalog and chat APIs. No hosted chat proxy or shared API key is used.
- Default key storage is per-tab sessionStorage; persistent localStorage storage requires the explicit remember checkbox.
- Chat records remain local to each browser. Existing VPS backend is retained separately for future OB work.

Online OB update (2026-11-11):
- Added browser PKCE authorization to the existing private OB service, refresh rotation and Streamable HTTP MCP sessions.
- Added memory search/overview/manual save, automatic per-turn retrieval, and Claude/OpenAI memory tool rounds with actual result feedback.
- Restricts tools to memory operations, requires explicit current-message delete intent and prevents duplicate uncertain writes within a turn.
- No vault import, disk restore, server upgrade or complete backup export was performed.

## 2026-11-11 聊天气泡与滚动修复

- 流式回复与最终消息共享 stream_id，完成后替换临时气泡，避免显示两份。
- 在内容增长前记录是否位于底部，长回复持续跟随；阅读旧消息时保留位置。
- 保留不同轮次中相同内容的合法消息，不改动已有聊天记录或 OB 数据。

## 2026-11-11 聊天 / 线下切换

- 默认自然聊天，页内切换线下场景互动，共用对话与记忆连接。
- 每条发送时锁定互动方式；线下记录在界面显示模式标签，传给模型时保留原文。
- 普通聊天和带记忆工具的聊天均注入对应指令；按用户确认的共用交流规则与各自风格执行，不对线下经历添加虚构定性。

## 2026-11-11 用户确认的内置预设

- 完整保留用户选定的八节长版交流基准，配合已确认的聊天与线下表达规则。
- 提示词原文存于 prompts/，生成 cloud/prompts.mjs 与 browser-provider.js，两种 API 协议及记忆读写分支共用。
- 本轮模式的表达要求优先于基准中的默认风格，关系、性格和记忆原则连续适用。
- 不给线下经历或历史消息添加“虚构/创作”定性，不更改已有记忆或聊天正文。

## 2026-11-11 Letter 正文入口与记忆载入修复

- 放行服务实际提供的 letter_read，面板和聊天工具均可读取信件正文，默认优先一封；信件锁由原 OB 校验。
- 自动载入改用 OB 端数量/token 预算，首次两路只读检索并行，核心结果缓存五分钟，写入后失效。
- 移除自动记忆的 6000/14000 字符硬截取和工具结果的 14000 字符硬截取，过大结果明确整份暂不载入。
- 加入检索耗时、首字等待、回复耗时和模型请求次数，无凭据或记忆正文进入诊断事件。
- 原 Nyx 的自动压缩与窗口机制尚未接入此纯前端版本；本次不更改 OB 服务或原数据。
