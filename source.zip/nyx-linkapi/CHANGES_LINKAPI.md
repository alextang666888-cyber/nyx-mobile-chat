# Changes for the personal LinkAPI starter

2026-11-11:
- Retained Nyx UI; simplified app navigation; added Chinese connection labels, explicit demo mode, and model/memory status.
- Added native Anthropic Messages conversion, streaming parser, tool-result conversion, premature-stream detection, and conservative request limits.
- Added single-process runtime joining Nyx Relay and the Tidal Echo API loop through in-process forwarding.
- Added opt-in remote OB MCP retrieval, limited tool allowlist and disabled long-term writes by default.
- Disabled optional desktop command/control plugins in minimal mode; restricted exposed relay routes; keep secrets out of static files.
- Fixed deterministic SQLite connection closure, disabled promotion of reasoning content into visible replies.
- Added functional checks, personal VPS examples and source distribution. No existing OB database was touched.

Backend additions: AGPL-3.0. Frontend changes retain the upstream CC BY-NC 4.0 license. Upstream attribution and license files remain included.

API settings update (2026-11-11):
- Added website-based provider URL/key entry, authenticated model discovery, optional public group catalog, model search/dropdown and saved selection.
- Group selection is a catalog filter, not an unauthorized billing-route override.
- Added hosted Worker transport with encrypted HttpOnly device settings cookie and device-local chat history. VPS mode retains server-side settings/history.
- OB remains backend-only; no memory settings panel or live OB changes.

Browser-only public update (2026-11-11):
- Removed website-account requirement from the main static experience.
- Browser directly fetches provider model/catalog and chat APIs. No hosted chat proxy or shared API key is used.
- Default key storage is per-tab sessionStorage; persistent localStorage storage requires the explicit remember checkbox.
- Chat records remain local to each browser. Existing VPS backend is retained separately for future OB work.

Online OB update (2026-11-11):
- Added browser PKCE authorization to the existing private OB service, refresh rotation and Streamable HTTP MCP sessions.
- Added memory search/overview/manual save, automatic per-turn retrieval, and Claude/OpenAI memory tool rounds with actual result feedback.
- Restricts tools to memory operations, requires explicit current-message delete intent and prevents duplicate uncertain writes within a turn.
- No vault import, disk restore, server upgrade or complete backup export was performed.
