/* Nyx upstream UI; minimal personal chat configuration. No provider secrets here. */
window.NYX = {
  relay: '/relay', contact: {id: 'songdu', name: '宋渡'}, aiName: '宋渡', meName: '我', title: 'Nyx', home: 'ink',
  treePhoto: null, stickers: null, stickerList: [], clawd: null, splash: null,
  tagline: '把话留在这里，慢慢接回记忆。',
  apps: [{id: 'chat', en: 'Chat', zh: '聊天', art: 'tokens'}]
};
