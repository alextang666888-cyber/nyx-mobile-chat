import os
from dotenv import load_dotenv
from pathlib import Path
load_dotenv(Path(__file__).with_name('.env'))
if __name__ == '__main__':
    import uvicorn
    uvicorn.run('runtime:app', host=os.environ.get('NYX_HOST', '127.0.0.1'), port=int(os.environ.get('PORT', '8088')), workers=1)
